package adapterpattern.main;

public class Address {
private String house;
private String street;
private String area;
private String city;

public String getHouse() {
	return house;
}
public void setHouse(String house) {
	this.house = house;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public String getArea() {
	return area;
}
public void setArea(String area) {
	this.area = area;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
@Override
public String toString() {
	return "Address [house=" + house + ",\n street=" + street + ",\n area=" + area + ",\n city=" + city + "]";
}

}
