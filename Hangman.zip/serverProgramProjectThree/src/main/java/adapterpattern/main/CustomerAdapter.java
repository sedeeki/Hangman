package adapterpattern.main;

public class CustomerAdapter {
	private FormData formData;
	private Customer customer;
	public CustomerAdapter(FormData formData){
		this.formData=formData;
		adaptData();
	}
	
	private void adaptData(){
		Address address= new Address();
		String[] addressArray = formData.getAddress().split(",");
		address.setHouse(addressArray[0]);
		address.setStreet(addressArray[1]);
		address.setArea(addressArray[2]);
		address.setCity(addressArray[3]);
		int age = Integer.parseInt(formData.getAge());
		customer= new Customer(formData.getName(),age,address);
	}

	public FormData getFormData() {
		return formData;
	}

	public void setFormData(FormData formData) {
		this.formData = formData;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
}
