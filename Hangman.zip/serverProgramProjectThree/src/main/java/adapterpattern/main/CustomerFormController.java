package adapterpattern.main;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class CustomerFormController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField ageField;

    @FXML
    private TextField addressField;

    @FXML
    private TextArea logField;

    @FXML
    void saveCusotmerData(ActionEvent event) {
    	StringBuilder sb= new StringBuilder();
    	logField.clear();
    	String name= nameField.getText();
    	String age= ageField.getText();
    	String address= addressField.getText();
    	sb.append("Parsing data in FormData Class\n");
    	FormData fd= new FormData(name,age,address);
    	sb.append("FormData Object:"+ fd +"\n\n\n");
    	logField.setText(sb.toString());
    	sb.append("Passing FormData in Adapter\n");
      	logField.setText(sb.toString());

    	sb.append("Converting FormData to Customer in Adapter\n\n\n");
      	logField.setText(sb.toString());
        
      	CustomerAdapter ca= new CustomerAdapter(fd);
      	
      	sb.append("Converted Customer: "+ca.getCustomer());
      	logField.setText(sb.toString());
        
    	
    }

}
