package adapterpattern.main;

public class FormData {
private String name;
private String age;
private String address;

public FormData(String name, String age, String address) {
	this.age=age;
	this.name=name;
	this.address=address;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
@Override
public String toString() {
	return "FormData [name=" + name + ",\n age=" + age + ",\n address=" + address + "]";
}

}
