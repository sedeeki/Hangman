package adapterpattern.main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Main extends Application{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		FXMLLoader loader= new FXMLLoader(Main.class.getResource("/fxml/FormView.fxml"));
		AnchorPane pane= loader.load();
		CustomerFormController contr= loader.getController();
		Scene scene= new Scene(pane);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

}
