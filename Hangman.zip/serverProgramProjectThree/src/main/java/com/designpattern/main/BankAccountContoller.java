package com.designpattern.main;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class BankAccountContoller {

    @FXML
    private TextField nameField;

    @FXML
    private TextArea logField;

    @FXML
    void generateBusinessAccount(ActionEvent event) {
    	if(!nameField.getText().isEmpty()){
    	logField.clear();
    	BusinessAccountCreater ba= new BusinessAccountCreater();
    	StringBuilder sb = ba.createAccount();
    	logField.setText(sb.toString());
    	}else{
    		logField.clear();
    		logField.setText("Please Enter Name");
    	}
    }

    @FXML
    void generatePrivateAccount(ActionEvent event) {
    if(!nameField.getText().isEmpty()){
    	logField.clear();
    	PrivateAccountCreater ba= new PrivateAccountCreater();
    	StringBuilder sb = ba.createAccount();
    	logField.setText(sb.toString());
    }else{
		logField.clear();
		logField.setText("Please Enter Name");
	}
    }

}
