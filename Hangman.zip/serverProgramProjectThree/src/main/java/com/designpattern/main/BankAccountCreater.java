package com.designpattern.main;

public class BankAccountCreater {
	public String verifyApplicationDetails(){
		return "Verify Application Details... Done\n";
	}
	public String verifyIdentificationDetails(){
		return "Verify Identification Details... Done\n";
	}
	public String receivePayment(){
		return "Payment Received\n";
	}
	public String generateAccountNumber(){
		return "Account Number Generated\n";
	}
	public String dispatchAtmCard(){
		return "ATM Card Dispatched\n";
	}
	
	public StringBuilder createAccount(){
		StringBuilder sb= new StringBuilder();
		sb.append(verifyApplicationDetails());
		sb.append(verifyIdentificationDetails());
		sb.append(receivePayment());
		sb.append(generateAccountNumber());
		sb.append(dispatchAtmCard());
		
		return sb;
	}
}
