package com.designpattern.main;

public class BusinessAccountCreater extends BankAccountCreater {

	@Override
	public String generateAccountNumber() {
		// TODO Auto-generated method stub
		return "Business Account Number Generated\n";
	}

	
}
