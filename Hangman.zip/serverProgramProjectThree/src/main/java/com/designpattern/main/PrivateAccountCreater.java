package com.designpattern.main;

public class PrivateAccountCreater extends BankAccountCreater{

	@Override
	public String generateAccountNumber() {
		// TODO Auto-generated method stub
		return "Private Account Number Generated\n";
	}

	
}
