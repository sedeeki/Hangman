import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;



public class FactoryTest {
	
	
	static CoffeeFactory cf;
	
	
	public void initialize() {
		cf = new CoffeeFactory();
	}
	
	
	
	@Test
	public void test1() {
		initialize();
		assertEquals(new ColdBrewCoffee().getClass(), CoffeeFactory.getCoffee("cb"));
	}
	
	@Test
	public void test2() {
		initialize();
		assertEquals(new LightRoastCoffee().getClass(), CoffeeFactory.getCoffee("lr"));
	}
	
	@Test
	public void test3() {
		initialize();
		assertEquals(new DarkRoastCoffee().getClass(), CoffeeFactory.getCoffee("dr"));
	}
	
	@Test
	public void test4() {
		initialize();
		assertEquals(new LightRoastCoffee().getClass(), CoffeeFactory.getCoffee("aa"));
	}
	
	
}
